<!DOCTYPE html>
<html>
<meta charset="utf-8">
<head>
	<link rel="stylesheet" type="text/css" href="estilo.css">
	<link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
	<title>Painel Login</title>
</head>
<body>
	<div class="login">
		<img src="icone.png" class="usuario" width="100" height="100" alt="">
		<h1>Login</h1>
		<form>

			<p>Usuário</p>
			<input type="text" name="" placeholder="Insira seu E-mail" required>
			<p>Senha</p>
			<input type="password" name="" placeholder="Insira sua senha" required>

			<a href="compras.php">
				
				<img src="entrar-botão.png"
				width="200px;">

			</a>

			<a href="senha.html">Esqueceu a Senha</a><br>
			<a href="cadatro.php">Ainda não sou cadastrado</a> 
			
		</form>
		
	</div>

</body>
</html>